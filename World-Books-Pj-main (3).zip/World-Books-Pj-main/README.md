 <h1>World Books</h1> 
   
> [!NOTE]
> Neste repositório estarão todas as informações sobre o projeto.

<div>
<h3>Programas/Plataformas que utilizei</h3>
<li><a href="https://code.visualstudio.com/">Visual Studio Code</a></li>
<li><a href=https://visualstudio.microsoft.com/pt-br/vs/">Visual Studio 2022</a></li>
<li><a href="https://www.mysql.com/">MySQL</a></li>
 <li><a href="https://www.w3schools.com/js/">W3schools</a></li>
</div>

 <br>
 
> [!TIP]
> **Confira um pouco do desenvolvimento do site: <a href="https://youtu.be/Rk2ybCaQH_I?si=QaMbu6Qk4D0SLrFG">World Books</a>**<br><br>
> Link do Website **(Somente interação visual.)**: <a href="https://pjuni.netlify.app">Site</a>

</a>
<img width="600px" src="captura.png">
